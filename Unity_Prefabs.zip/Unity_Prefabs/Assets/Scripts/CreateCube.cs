﻿using UnityEngine;
using System.Collections;

public class CreateCube : MonoBehaviour {

    // Use this for initialization
    private GameObject cube1;
    public Transform wall1;
    //int x, y;
    void Start()
    {

        for (int y = 0; y < 5; y++)
        {
            for (int x = 0; x < 11; x++)
            {
                cube1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                //cube1.AddComponent<Rigidbody>();
                cube1.transform.position = new Vector3(x, y, 0);
                cube1.GetComponent<Renderer>().material.color = Color.blue;
                
            }
        }

        for (int y = 0; y < 5; y++)
        {
            for (int z = 0; z < 11; z++)
            {
                Instantiate(wall1, new Vector3(0, y, z), Quaternion.identity);
                wall1.transform.position = new Vector3(0, y, z);
                wall1.GetComponent<Renderer>().material.color = Color.red;
            }
        }
    }
}

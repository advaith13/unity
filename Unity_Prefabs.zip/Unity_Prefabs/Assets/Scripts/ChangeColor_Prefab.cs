﻿using UnityEngine;
using System.Collections;

public class ChangeColor_Prefab : MonoBehaviour {

    // Use this for initialization
    // public Transform brick;
    public GameObject cube1;
    void Start () {
        for (int y = 0; y < 5; y++)
        {
            for (int x = 0; x < 5; x++)
            {
                cube1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                //cube1.AddComponent<Rigidbody>();
                cube1.transform.position = new Vector3(x, y, 0);
            }
        }
        for (int y = 0; y < 5; y++)
        {
            for (int x = 0; x < 5; x++)
            {
                Instantiate(cube1, new Vector3(x, y, 0), Quaternion.identity);
            }
        }

    }
	
	
}
